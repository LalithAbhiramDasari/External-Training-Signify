package com.signify.student.calculator;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


class Numbers
{
	private double num1;
	private double num2;
	
	public double getNum1() 
	{
        return num1;
    }

    public void setNum1(double num1) 
    {
        this.num1 = num1;
    }

    public double getNum2() 
    {
        return num2;
    }

    public void setNum2(double num2)
    {
        this.num2 = num2;
    }
}


@RestController
public class Calculator 
{
	@PostMapping("/add")
    public double add(@RequestBody Numbers numbers)
	{
        return numbers.getNum1() + numbers.getNum2();
    }

    @PostMapping("/subtract")
    public double subtract(@RequestBody Numbers numbers)
    {
        return numbers.getNum1() - numbers.getNum2();
    }

    @PostMapping("/multiply")
    public double multiply(@RequestBody Numbers numbers) 
    {
        return numbers.getNum1() * numbers.getNum2();
    }

    @PostMapping("/divide")
    public double divide(@RequestBody Numbers numbers) 
    {
    	
    	try
    	{
    		if(numbers.getNum2() == 0)
    		{
    			throw new ArithmeticException("Cannot divide by zero!");
    		}
    		return numbers.getNum1() / numbers.getNum2();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return Double.NaN;
    	}
    	
    }
}
