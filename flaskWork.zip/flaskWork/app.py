from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, login_user, UserMixin, logout_user, login_required

app = Flask(__name__)

app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///swms.db'
app.config['SECRET_KEY'] = "secretkey"
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False) 
    phone = db.Column(db.String(10), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name1 = request.form["name"]
        phone1 = request.form["phone"]
        password1 = request.form["password"]
        if User.query.filter_by(phone=phone1).first():
            return "User with this phone number already exists."
        hashed_password = bcrypt.generate_password_hash(password1).decode('utf-8')
        user = User(name=name1, phone=phone1, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        return redirect(url_for("login"))
    
    return render_template("register.html")

@app.route("/login", methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        phoneLogin = request.form['phone']
        passwordLogin = request.form['password']
        user = User.query.filter_by(phone=phoneLogin).first()
        if not user:
            return "User not found."
        if bcrypt.check_password_hash(user.password, passwordLogin):
            login_user(user)
            return redirect(url_for('main'))
        else:
            return "Invalid phone number or password."
    return render_template("login.html")

@app.route("/main")
def main():
    return render_template("main.html")

@app.route("/logout")
def logout():
    logout_user()
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, port=5002)
